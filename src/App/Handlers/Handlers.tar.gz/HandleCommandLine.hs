module App.Handlers.HandleCommandLine where



data HandleCommandLine m = HandleCommandLine
  { readCommandLine :: String -> Maybe a }





